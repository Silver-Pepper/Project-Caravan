﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ProjectGeorge.Entities
{
    public class MerchantData
    {
        public string name = "George";
        // public string id;
        public float money;
        public int slaves;
        public float baseSpeed;
    }
}
